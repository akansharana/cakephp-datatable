var lib = [
    '/css/jquery.dataTables.css',
    '/js/jquery.dataTables.min.js',
]